import javax.swing.JOptionPane;
public class Task {
   
    private int totalDuration = 0;
   
    public  String getInput(String prompt){
        return JOptionPane.showInputDialog(null,prompt);
    }
   
    public int showOptions(){
        while (true){
            String input = getInput("Pick one:\n" +
                "1. Add tasks\n" +
                "2. Show report\n" +
                "3. Quit"
            );
            
            int choice = 0;

            try {
                choice = Integer.parseInt(input);
                 } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
                continue; // Restart the loop if input is invalid
            }

            if (choice >= 1 && choice <= 3) {
            return choice; // Exit the loop and return valid choice
        } else {
            JOptionPane.showMessageDialog(null, "Invalid choice. Select a valid option.");
        }
            }  
    }
   
    public void addTasks(){
        int numberOfTasks ;
        
        do {
            String numberOfTasksInput = JOptionPane.showInputDialog("Enter the number of tasks you wish to enter:");
            try {
                numberOfTasks  = Integer.parseInt(numberOfTasksInput);
                if (numberOfTasks > 0) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Enter a valid number of tasks.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Enter a valid number.");
            }
        } while (true);

        int taskNumber = 0;
       
        for (int i = 0; i < numberOfTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter the name of task :");
            String taskDescription;
            do {
                taskDescription = JOptionPane.showInputDialog("Describe task :");
                if (taskDescription == null || taskDescription.length() <= 50) {
                    JOptionPane.showMessageDialog(null, "Task successfully captured");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                }
            } while (true);
            String developerDetails = JOptionPane.showInputDialog("Enter the developers full name for task :");
            int taskDuration;
            do {
                String taskDurationInput = JOptionPane.showInputDialog("Enter the number of hours the task would take:");
                try {
                    taskDuration = Integer.parseInt(taskDurationInput);
                    if (taskDuration >= 0) {
                        break;
                    } else {
                        JOptionPane.showMessageDialog(null, "Please enter a valid positive number for task duration.");
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid number for task duration.");
                }
            } while (true);
            totalDuration += taskDuration;
           
            String taskID = createTaskID(taskName, taskNumber, developerDetails);
            JOptionPane.showMessageDialog(null, "Task ID: " + taskID.toUpperCase());
           
            String taskStatus;
            do {
                String input = getInput("Pick one:\n" +
                    "1. To Do\n" +
                    "2. Done\n" +
                    "3. Doing"
                );

                if (input != null && !input.isEmpty()) {
                    int choice;
                    try {
                        choice = Integer.parseInt(input);
                    if (choice >= 1 && choice <= 3) {
                        switch (choice) {
                            case 1:
                                taskStatus = "To Do";
                                break;
                            case 2:
                                taskStatus = "Done";
                                break;
                            case 3:
                                taskStatus = "Doing";
                                break;
                            default:
                                taskStatus = ""; // Default case added for compiler satisfaction
                                break;
                        }
                        break;
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
                }
            }
        } while (true);
           
            String taskDetails = printTaskDetails(taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration);
            JOptionPane.showMessageDialog(null, taskDetails);
           
            taskNumber++;
        }
        JOptionPane.showMessageDialog(null, "The total number of hours all the tasks would take: " + returnTotalHours() + " hours");
    }
   
    public boolean checkTaskDescription(String taskDescription) {
        boolean isValidTaskDescription = false;
        do {
            taskDescription = JOptionPane.showInputDialog("Describe task:");
            isValidTaskDescription = taskDescription != null && taskDescription.length() <= 50;
            if (!isValidTaskDescription) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of 50 characters or less.");
            }
        } while (!isValidTaskDescription);

        return isValidTaskDescription; // Ensure the method returns a boolean value
    }
   
    public String createTaskID(String taskName, int taskNumber, String developerName){
        String prefix = taskName.substring(0, Math.min(taskName.length(), 2)).toUpperCase();
        String suffix = developerName.substring(Math.max(developerName.length() - 3, 0)).toUpperCase();

        return prefix + ":" + taskNumber + ":" + suffix;
    }
   
    public String printTaskDetails(String taskStatus, String developerDetails, int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration){
        return String.format(
            "Task status: %s\nDeveloper details: %s\nTask number: %d\nTask name: %s\nTask description: %s\nTask ID: %s\nDuration: %s hours",taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID.toUpperCase(), taskDuration
        );
    }
   
    public int returnTotalHours(){
        return totalDuration;
    }
}
