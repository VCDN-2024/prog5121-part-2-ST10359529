
package progpoe5121;

import java.util.Scanner;

public class ProgPOE5121 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter your username: ");
        String username = scanner.nextLine();
        
        System.out.println("Enter your password: ");
        String password = scanner.nextLine();
        if (!Login.checkPasswordComplexity(password)){
                System.out.println("Invalid.");
                return;
        }
                
        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();
        
        System.out.println("Enter your last name: ");
        String lastName = scanner.nextLine();
        
        Login register = new Login();
        register.registerUser(username, password, firstName, lastName);
        String Status = register.returnLoginStatus();
        System.out.println(Status);
    }
    
    //reference list
    // 1. A computer science portal for geeks (no date) GeeksforGeeks. Available at: https://www.geeksforgeeks.org/ (Accessed: 30 May 2024). 
    // my loom video link: https://www.loom.com/share/980edb53982d47be970e6bf8029574dc?sid=fdff5fe7-56e2-4672-b57f-6feaed152b12
}
