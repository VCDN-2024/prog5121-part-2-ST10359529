package progpoe5121;

public class Login {
    String username;
    String password;
    String firstName;
    String lastName;
    
    public static boolean checkUserName(String username){
        if (username.length() <= 5 && username.contains("_")){
            return true;
        }
        return false;
    }
    
    public static boolean checkPasswordComplexity(String password){
        if (password == null){
            return false;
        }
        boolean isLength = password.length() >= 8;
        boolean isCapital = !password.equals(password.toLowerCase());
        boolean isNumber = password.matches(".*\\d.*");
        boolean isSpecialChar = !password.matches("[a-zA-Z0-9 ]*");
        
        return isLength && isCapital && isNumber && isSpecialChar;
    }
    
    public boolean loginUser(String inputUsername, String inputPassword){
        return inputUsername.equals(username) && inputPassword.equals(password);
    }
    
    public void registerUser(String username, String password, String firstName, String lastName){
        if(checkPasswordComplexity(password) && username != null && username.length() <= 5 && username.contains("_")){            
            System.out.println("Username and Password successfully captured");
            this.password = password;
            this.username = username;
        }else{
            System.out.println("Username and Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
        }
        
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    public String returnLoginStatus(){
        if(loginUser(username,password)){
            return "Welcome " + firstName + " " + lastName + " it is great to see you again.";
        }else{
            return "Username or password incorrect, please try again";
        }
    }
    
}
