import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import javax.swing.JOptionPane;

public class TaskTest {

    private Task task;

    @BeforeEach
    public void setUp() {
        task = new Task();
    }

    @Test
    public void testCheckTaskDescriptionValid() {
        String validDescription = "This is a valid task description.";
        assertTrue(task.checkTaskDescription(validDescription));
    }

    @Test
    public void testCheckTaskDescriptionInvalid() {
        String invalidDescription = "This task description is way too long and exceeds the fifty character limit.";
        assertFalse(task.checkTaskDescription(invalidDescription));
    }

    @Test
    public void testCreateTaskID() {
        String taskName = "TaskName";
        int taskNumber = 1;
        String developerName = "John Doe";
        String expectedTaskID = "TA:1:DOE";
        assertEquals(expectedTaskID, task.createTaskID(taskName, taskNumber, developerName));
    }

    @Test
    public void testReturnTotalHours() {
        // Simulating adding tasks
        task.addTasks();
        // Assuming total duration should be 0 since we haven't actually added any tasks
        assertEquals(0, task.returnTotalHours());
    }

    @Test
    public void testPrintTaskDetails() {
        String taskStatus = "To Do";
        String developerDetails = "John Doe";
        int taskNumber = 1;
        String taskName = "TaskName";
        String taskDescription = "A task description.";
        String taskID = "TA:1:DOE";
        int taskDuration = 5;

        String expectedDetails = "Task status: To Do\n" +
                "Developer details: John Doe\n" +
                "Task number: 1\n" +
                "Task name: TaskName\n" +
                "Task description: A task description.\n" +
                "Task ID: TA:1:DOE\n" +
                "Duration: 5 hours";

        assertEquals(expectedDetails, task.printTaskDetails(taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration));
    }

    
}
